export MLFLOW_TRACKING_URI="https://mlflowjedha0724-c4f1f2d6f710.herokuapp.com"
export AWS_ACCESS_KEY_ID="AKIAQE43JYZM4RPMUJKP"
export AWS_SECRET_ACCESS_KEY="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"
export BACKEND_STORE_URI="postgresql://u57lbucbfe083a:p54b76d30f5b7b9659da9e6d154e298f270bbee3e0ec10e3492569cd396913a90@ce0lkuo944ch99.cluster-czrs8kj4isg7.us-east-1.rds.amazonaws.com:5432/d6ouugp7upli2b"
export ARTIFACT_ROOT="s3://jedha-deployment-0724/mlflow/"




