import requests

r = requests.get("http://localhost:4000/blog-articles/1")
print(r.content)