import requests
r = requests.get("http://localhost:4000/custom-greetings", params={"name":"Sabrine"})
print(r.content)


#http://localhost:4000/custom-greetings?name=Charles
