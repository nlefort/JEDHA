print("hello")
print("how are you")


# docker rm -f $(docker ps -aq); docker rmi -f $(docker image ls -q)
# option + shift + L -> Pipe
# docker run -it -v "$(pwd):/home/app" jedha/data-fullstack-demo-image


# docker ps -a
# docker images

# docker stop $(docker ps -aq)


docker run -it jedha/data-fullstack-demo-image