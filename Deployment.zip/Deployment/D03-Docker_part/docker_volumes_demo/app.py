print("Hello World from Jedha!")
print("hi, im ok and you ? ")
print("hi, hi")