import requests

url = "http://localhost:8000/predict"
data = {"YearsExperience": 5.0}

res = requests.post(url, json=data)

print("📦 Status Code:", res.status_code)
print("📄 Raw Response Text:", res.text)
