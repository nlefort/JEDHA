docker run -it \
  -p 8000:8000 \
  -e PORT=8000 \
  fastapi-api
