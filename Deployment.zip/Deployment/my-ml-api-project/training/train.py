import pandas as pd
import time
import mlflow
from mlflow.models.signature import infer_signature
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression

# 👇 Add these two lines
mlflow.set_tracking_uri("http://localhost:4000")
mlflow.set_experiment("salary_prediction")

if __name__ == "__main__":

    print("training model...")
    start_time = time.time()

    mlflow.sklearn.autolog(log_models=False)

    df = pd.read_csv("data/Salary_Data.csv")
    X = df.loc[:, ["YearsExperience"]]
    y = df.loc[:, ["Salary"]]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3)

    with mlflow.start_run() as run:
        model = LinearRegression()
        model.fit(X_train, y_train)
        predictions = model.predict(X_train)
        mlflow.sklearn.log_model(sk_model=model, artifact_path="salary_estimator")

    print("...Done!")
    print(f"---Total training time: {time.time()-start_time:.2f}s")
